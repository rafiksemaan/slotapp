<!-- pages/404.php -->
<div class="container">
    <h2>Page Not Found</h2>
    <p>The requested page does not exist.</p>
</div>